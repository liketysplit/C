float add_with_tax(float);

