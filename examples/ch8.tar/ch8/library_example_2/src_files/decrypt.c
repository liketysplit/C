#include "decrypt.h"
#include "encrypt.h"

void decrypt(char *message){
	encrypt(message);
}
