void decrypt(char *);
