void encrypt(char *);
