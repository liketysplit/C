int checksum(char *);
