#include "encrypt.h"

void decrypt(char *);

