#include "decrypt.h"


void decrypt(char *message){
	encrypt(message);
}
