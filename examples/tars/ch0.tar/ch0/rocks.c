#include <stdio.h>
#include <limits.h>

int main () {
	puts("C Rocks!");
	printf("CHAR_MIN=%d\n", CHAR_MIN);
	return 0;
}

