int getNeighborValue(int, int, int, int);
