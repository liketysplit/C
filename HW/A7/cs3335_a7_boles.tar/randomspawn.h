void randomSpawner(int numOfOrganismsToSpawn, int length, int width);
