void lifeRules(int, int);
