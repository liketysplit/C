void titleCreation(int selection, int width);

