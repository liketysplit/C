#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <unistd.h>

#define HEIGHT 100
#define WIDTH 100
#define LIFE_YES 1
#define LIFE_NO 0


typedef int TableType[HEIGHT][WIDTH];


