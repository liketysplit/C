int neighborCount(int, int, int, int);


