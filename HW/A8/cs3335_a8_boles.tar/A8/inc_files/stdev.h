double stdev(double , double );
