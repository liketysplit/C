double mean(double);
