#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define MAX_ITEM 8
typedef double TableType[MAX_ITEM];

