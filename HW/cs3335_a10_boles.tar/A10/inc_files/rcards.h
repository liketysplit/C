#include "globals.h"
int rCard(int []);
