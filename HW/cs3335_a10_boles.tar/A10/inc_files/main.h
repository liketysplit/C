#include "globals.h"
card *create(int);
