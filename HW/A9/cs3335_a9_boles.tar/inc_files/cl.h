void *insert(void *cursor, void *name);
void *release(void *cursor);
void *advance(void *cursor);
void print(void *cursor);
